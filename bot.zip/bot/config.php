<?php
/*
channel => @mirzapanel
*/
//-----------------------------database-------------------------------
$dbname = "beta"; //  نام دیتابیس
$usernamedb = "beta"; // نام کاربری دیتابیس
$passworddb = "Aa0930895"; // رمز عبور دیتابیس
$connect = mysqli_connect("localhost", $usernamedb, $passworddb, $dbname);
if ($connect->connect_error) {
    die("The connection to the database failed:" . $connect->connect_error);
}
mysqli_set_charset($connect, "utf8mb4");
//-----------------------------info-------------------------------

$APIKEY = "6603197867:AAGC4my3ZsAl1_PyEypH_TJFhwZnoQchfKQ"; // توکن ربات خود را وارد کنید
$adminnumber = "6123092887";// آیدی عددی ادمین
$domainhosts = "beta.sigma-hoster.store/bot";// دامنه  هاست و مسیر سورس
$usernamebot = "betasigma_bot"; //نام کاربری ربات  بدون @